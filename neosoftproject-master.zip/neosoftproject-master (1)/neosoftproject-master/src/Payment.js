// ----------------Call Payment --------Function 

function Payment()
{
    return(
        <h1>payment</h1>
    )
}
export default Payment